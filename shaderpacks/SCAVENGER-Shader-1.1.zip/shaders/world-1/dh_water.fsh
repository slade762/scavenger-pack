#version 130

#define THE_NETHER
#define DH_WATER

#include "/program/translucent.fsh"
