#version 130

#define OVERWORLD
#define GBUFFERS_TERRAIN
#define DH_TERRAIN

#include "/program/textured_lit.vsh"
