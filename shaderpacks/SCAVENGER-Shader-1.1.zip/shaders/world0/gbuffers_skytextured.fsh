#version 120

#include "/shader.h"

// SCAVENGER: with the Photon sky on, the vanilla (square) sun and moon are hidden;
// the sky pass draws its own round ones.

uniform sampler2D texture;

varying vec2 uv;
varying vec4 col;

void main() {
   #ifdef SCAV_SKY
      discard;
   #endif

   /* DRAWBUFFERS:0 */
   gl_FragData[0] = texture2D(texture, uv) * col;
}
