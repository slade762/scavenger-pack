#version 130

#define OVERWORLD

#include "/program/skyfog.fsh"
