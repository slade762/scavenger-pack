// ---------------------------------------------------------------------------
// SCAVENGER clouds (stage 4): one cumulus layer, raymarched in the sky pass.
// Look and lighting modelled on Photon's cumulus clouds (SixthSurge, Photon Shaders License):
// dual-lobe Henyey-Greenstein phase, multiple-scattering approximation, sky-coloured ambient,
// aerial perspective toward the horizon. Much cheaper: one layer, few steps, our own 64^3 noise.
// ---------------------------------------------------------------------------

uniform sampler3D scavCloudNoise;
uniform float frameTimeCounter;

const float CL_BOTTOM = CLOUD_ALTITUDE;
const float CL_TOP    = CLOUD_ALTITUDE + CLOUD_THICKNESS;

float cl_hg(float c, float g) {
   float gg = g * g;
   float p = 1.0 + gg - 2.0 * g * c;
   return (1.0 - gg) / (4.0 * ph_pi * p * sqrt(p));
}

float cl_density(vec3 p, bool detail) {
   float h = (p.y - CL_BOTTOM) / CLOUD_THICKNESS;
   if (h < 0.0 || h > 1.0) return 0.0;

   vec3 w = p + vec3(1.0, 0.0, 0.35) * frameTimeCounter * CLOUD_SPEED;

   float cov = CLOUD_COVERAGE + 0.3 * rainStrength;
   float big = texture(scavCloudNoise, vec3(w.xz / 9000.0, 0.37).xzy).r;   // weather: where clouds can be
   float shape = texture(scavCloudNoise, w / 2200.0).r;

   // rounded cumulus: flat-ish bottom, domed top
   float grad = smoothstep(0.0, 0.12, h) * smoothstep(1.0, 0.45, h);

   float d = (shape * 0.65 + big * 0.55) * grad - (1.0 - cov);
   if (d <= 0.0) return 0.0;

   if (detail) {
      float e = texture(scavCloudNoise, w / 420.0).g;
      d -= (1.0 - e) * 0.18 * (1.0 - clamp(d * 4.0, 0.0, 1.0));
   }
   return clamp(d * 3.0, 0.0, 1.0);
}

// returns vec4(scattered light (rec2020), transmittance)
vec4 scavClouds(vec3 ray, vec3 skyUp, vec3 atmo, float dither) {
   vec3 cam = cameraPosition;
   if (ray.y <= 0.002 && cam.y < CL_BOTTOM) return vec4(0.0, 0.0, 0.0, 1.0);

   float t0, t1;
   if (cam.y < CL_BOTTOM) {
      t0 = (CL_BOTTOM - cam.y) / ray.y;
      t1 = (CL_TOP - cam.y) / ray.y;
   } else if (cam.y > CL_TOP) {
      if (ray.y >= 0.0) return vec4(0.0, 0.0, 0.0, 1.0);
      t0 = (CL_TOP - cam.y) / ray.y;
      t1 = (CL_BOTTOM - cam.y) / ray.y;
   } else {
      t0 = 0.0;
      t1 = ray.y > 0.0 ? (CL_TOP - cam.y) / ray.y : (ray.y < 0.0 ? (CL_BOTTOM - cam.y) / ray.y : 4000.0);
   }
   if (t0 > 40000.0) return vec4(0.0, 0.0, 0.0, 1.0);
   t1 = min(t1, t0 + 5000.0);

   // light: the sun by day, the moon by night
   bool day = sun_dir.y > -0.02;
   vec3 L = day ? sun_dir : moon_dir;
   vec3 lightCol = day ? ph_sunlight_color * ph_transmittance(max(sun_dir.y, 0.0)) * ph_sun_color()
                       : ph_moon_color() * 0.6;
   lightCol *= smoothstep(-0.02, 0.06, L.y) * (1.0 - 0.7 * rainStrength);

   float c = dot(ray, L);
   float phase = mix(cl_hg(c, 0.65), cl_hg(c, -0.25), 0.3);
   float phase2 = mix(cl_hg(c, 0.3), cl_hg(c, -0.1), 0.3); // softer lobe for multiple scattering

   const float sigma = 0.035; // extinction per block at density 1
   float stepLen = (t1 - t0) / float(CLOUD_STEPS);
   vec3 scat = vec3(0.0);
   float T = 1.0;

   for (int i = 0; i < CLOUD_STEPS; i++) {
      vec3 p = cam + ray * (t0 + stepLen * (float(i) + dither));
      float d = cl_density(p, true);
      if (d <= 0.0) continue;

      // optical depth toward the light (3 short steps)
      float od = 0.0;
      od += cl_density(p + L *  30.0, false) * 30.0;
      od += cl_density(p + L *  90.0, false) * 60.0;
      od += cl_density(p + L * 210.0, false) * 120.0;
      od *= sigma;

      float h = clamp((p.y - CL_BOTTOM) / CLOUD_THICKNESS, 0.0, 1.0);
      float powder = 1.0 - 0.6 * exp(-d * 6.0);
      vec3 direct = lightCol * (exp(-od) * phase + 0.35 * exp(-od * 0.25) * phase2) * 4.0 * ph_pi * 0.35 * powder;
      vec3 ambient = skyUp * (0.35 + 0.65 * h) * (1.0 - 0.4 * rainStrength);

      float stepT = exp(-d * sigma * stepLen);
      scat += T * (1.0 - stepT) * (direct + ambient);
      T *= stepT;
      if (T < 0.02) break;
   }

   // far clouds fade into the atmosphere (aerial perspective) and out near the horizon
   float fade = exp(-t0 / 18000.0);
   scat = mix(atmo * (1.0 - T), scat, fade);
   float vis = cam.y >= CL_BOTTOM ? 1.0 : smoothstep(0.0, 0.05, ray.y) * smoothstep(40000.0, 20000.0, t0);
   T = mix(1.0, T, vis);
   scat *= vis;
   T = clamp(T, 0.0, 1.0);
   return vec4(scat * CLOUD_BRIGHTNESS, T);
}
