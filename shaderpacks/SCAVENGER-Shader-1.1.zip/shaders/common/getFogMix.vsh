uniform float fogEnd, fogStart;
uniform float near, far;

#ifdef DISTANT_HORIZONS
   uniform int dhRenderDistance;
#endif

float calcFogMix(vec3 feetPos, float fogStartMult, float far) {
   float len = length(feetPos);
   float cylinderLen = max(length(feetPos.xz), abs(feetPos.y));

   return max(
      rescale(len, fogStartMult * fogStart, fogEnd),
      rescale(cylinderLen, fogStartMult * (far - clamp(0.1 * far, 4.0, 64.0)), far)
   );
}

float getFogMixBase(vec3 feetPos) {
   #if defined VOXY && !defined GBUFFERS_SKYBASIC && !defined GBUFFERS_CLOUDS
      float far = 48000.0;
      float near = 16.0;
   #endif

   // Distant Horizons (SCAVENGER edit): fog ends at the edge of the LODs, not at the vanilla render distance.
   #if defined DISTANT_HORIZONS && !defined VOXY && !defined GBUFFERS_SKYBASIC && !defined GBUFFERS_CLOUDS
      float vanillaFar = far;
      float far = max(float(dhRenderDistance), vanillaFar);

      #ifndef ENABLE_FOG
         if (fogEnd >= 0.5 * vanillaFar) {
            return 0.0;
         }
      #endif

      if (fogEnd < 0.5 * vanillaFar) {
         // blindness / darkness / lava / water fog: vanilla distances
         return calcFogMix(feetPos, 1.0, vanillaFar);
      }

      #ifdef OVERWORLD
         float dx = worldTime * NORMALIZE_TIME;

         dx = clamp(25.0*(dx < MIDNIGHT ? SUNSET - dx : dx - SUNRISE) + 0.3,
                    OVERWORLD_FOG_MIN,
                    OVERWORLD_FOG_MAX);

         dx = min(dx, 1.0 - rainStrength);
      #else
         float dx = 1.0;
      #endif

      float dhCylinder = max(length(feetPos.xz), abs(feetPos.y));

      return rescale(dhCylinder, dx * (far - clamp(0.1 * far, 4.0, 64.0)), far);
   #endif

   #ifndef ENABLE_FOG
      if (fogEnd >= far) {
         return 0.0;
      }
   #endif

   #if MC_VERSION >= 11700
      if (fogEnd < far) {
         // a fog effect (like blindness) is active
         return calcFogMix(feetPos, 1.0, far);
      }

      #if defined GBUFFERS_SKYBASIC
         return 0.0;
      #elif defined GBUFFERS_CLOUDS
         return clamp((length(feetPos) - far) * (near * 0.01), 0.0, 1.0);
      #else
         #ifdef OVERWORLD
            float x = worldTime * NORMALIZE_TIME;

            x = clamp(25.0*(x < MIDNIGHT ? SUNSET - x : x - SUNRISE) + 0.3,
                     OVERWORLD_FOG_MIN,
                     OVERWORLD_FOG_MAX);

            x = min(x, 1.0 - rainStrength);
         #else
            float x = 1.0;
         #endif

         return calcFogMix(feetPos, x, far);
      #endif
   #else
      gl_FogFragCoord = length(feetPos);

      return (isEyeInWater > 0) ? 1.0 - exp(-gl_FogFragCoord * gl_Fog.density)
                                : clamp((gl_FogFragCoord - gl_Fog.start) * gl_Fog.scale, 0.0, 1.0);
   #endif
}

// SCAVENGER: heavy atmospheric fog on top of Miniature's own (never fully solid, so silhouettes survive)
float getFogMix(vec3 feetPos) {
   #if defined SCAV_SKY && defined OVERWORLD && !defined GBUFFERS_SKYBASIC && !defined GBUFFERS_CLOUDS
      // normal overworld fog is drawn later in composite, coloured by the sky
      if (isEyeInWater == 0 && fogEnd >= 0.5 * far) return 0.0;
   #endif

   float base = getFogMixBase(feetPos);

   #if defined ZONE_FOG && !defined GBUFFERS_SKYBASIC && !defined GBUFFERS_CLOUDS && !defined THE_NETHER && !defined THE_END
      if (fogEnd >= 0.5 * far) { // not during blindness / water / lava fog
         float d = length(feetPos) / (ZONE_FOG_DISTANCE * (1.0 - 0.45 * rainStrength));
         float zone = ZONE_FOG_MAX * (1.0 - exp(-d));
         return max(base, zone);
      }
   #endif

   return base;
}
