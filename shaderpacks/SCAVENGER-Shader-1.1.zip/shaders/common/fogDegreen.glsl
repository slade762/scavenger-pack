// SCAVENGER: the final colour grade tints everything olive. For fog and haze, partly cancel that
// tint beforehand so the air reads grey-blue instead of green (FOG_DEGREEN 0 = old look).
vec3 fogDegreen(vec3 c) {
   #ifdef COLOR_GRADE
      vec3 k = mix(vec3(1.0), vec3(0.96, 1.0, 0.84), GRADE_TINT);
      vec3 comp = vec3(luma(k)) / k;
      return c * mix(vec3(1.0), comp, FOG_DEGREEN);
   #else
      return c;
   #endif
}
