// SCAVENGER: height fog amount along a world-space view ray (shared by the fog pass and the fog blur).
// Density 1 at/below ZONE_FOG_BASE, exp(-height / ZONE_FOG_FALLOFF) above it, integrated analytically.
float zoneFogAmount(vec3 ray, float dist) {
   float dens = 1.0 / (ZONE_FOG_DISTANCE * (1.0 - 0.45 * rainStrength));
   const float H = ZONE_FOG_FALLOFF;
   float y0 = max(cameraPosition.y - ZONE_FOG_BASE, 0.0);
   float dy = ray.y;
   float od;
   if (abs(dy) < 1e-4) {
      od = dist * exp(-y0 / H);
   } else {
      float tBase = dy < 0.0 ? y0 / -dy : 1e9;  // where the ray reaches the base
      float tA = min(dist, tBase);
      od = H * (exp(-y0 / H) - exp(-(y0 + dy * tA) / H)) / dy;
      od += max(dist - tBase, 0.0);
   }
   // no fog builds up in the first ZONE_FOG_START blocks: the thick fog sits further out
   // (soft ramp-in around the start instead of a line)
   od *= smoothstep(0.5 * ZONE_FOG_START, 2.0 * ZONE_FOG_START + 1.0, dist);
   od = max(od, 0.0) * dens;
   // gentle build: od / (1 + od) reaches half strength at od = 1 and keeps creeping up
   // instead of slamming into the maximum like 1 - exp(-od)
   return ZONE_FOG_MAX * od / (1.0 + od);
}
