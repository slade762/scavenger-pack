// ---------------------------------------------------------------------------
// SCAVENGER sky: precomputed atmosphere, sun, moon and sunset colours.
//
// Ported and trimmed from Photon Shaders by SixthSurge (Benjamin Stott),
// (c) 2021-2025, used under the Photon Shaders License Agreement
// (see PHOTON_LICENSE.txt). The scattering lookup table
// (image/atmosphere/scattering.dat) is Photon's.
//
// LUT mapping functions from Eric Bruneton's precomputed atmospheric
// scattering, Copyright (c) 2017 Eric Bruneton, BSD 3-clause:
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
// 3. Neither the name of the copyright holder nor the names of its
//    contributors may be used to endorse or promote products derived from this
//    software without specific prior written permission.
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES ARE DISCLAIMED.
// ---------------------------------------------------------------------------

#ifndef PH_LIGHT_ONLY
uniform sampler3D scavAtmosphereLUT;
#endif

uniform vec3 sun_dir;   // world space, from shaders.properties
uniform vec3 moon_dir;
uniform float time_sunrise, time_sunset;
uniform float atmosphere_saturation_boost_amount;
uniform float sunAngle;
uniform int moonPhase;

const float ph_pi  = 3.14159265;
const float ph_tau = 6.28318531;
const float ph_degree = ph_tau / 360.0;
const float ph_eps = 1e-6;

const mat3 ph_xyz_to_rec709  = mat3(3.2406, -1.5372, -0.4986, -0.9689, 1.8758, 0.0415, 0.0557, -0.2040, 1.0570);
const mat3 ph_rec709_to_xyz  = mat3(0.4124, 0.3576, 0.1805, 0.2126, 0.7152, 0.0722, 0.0193, 0.1192, 0.9505);
const mat3 ph_xyz_to_rec2020 = mat3(1.7166084, -0.3556621, -0.2533601, -0.6666829, 1.6164776, 0.0157685, 0.0176422, -0.0427763, 0.94222867);
const mat3 ph_rec2020_to_xyz = mat3(0.6369736, 0.1446172, 0.1688585, 0.2627066, 0.6779996, 0.0592938, 0.0, 0.0280728, 1.0608437);
// row-vector convention, like Photon: colour * matrix
const mat3 ph_rec709_to_rec2020 = ph_rec709_to_xyz * ph_xyz_to_rec2020;
const mat3 ph_rec2020_to_rec709 = ph_rec2020_to_xyz * ph_xyz_to_rec709;
const vec3 ph_lum2020 = vec3(0.2627, 0.6780, 0.0593);

const vec3 ph_sunlight_color = vec3(1.051, 0.985, 0.940);
const float ph_sun_radius  = PH_SUN_SIZE * ph_degree;
const float ph_moon_radius = PH_MOON_SIZE * ph_degree;

const float ph_planet_radius = 6371e3;
const float ph_atmo_inner = ph_planet_radius - 1e3;
const float ph_atmo_outer = ph_planet_radius + 110e3;
const float ph_atmo_thickness = ph_atmo_outer - ph_atmo_inner;
const float ph_min_mu_s = -0.35;
const vec3 ph_scatter_res = vec3(16.0, 64.0, 32.0);
const vec2 ph_scale_heights = vec2(8.4e3, 1.25e3);

float ph_sqr(float x) { return x * x; }
float ph_linstep(float a, float b, float x) { return clamp((x - a) / (b - a), 0.0, 1.0); }
float ph_pulse(float x, float c, float w) {
   x = abs(x - c) / w;
   return x > 1.0 ? 0.0 : 1.0 - x * x * (3.0 - 2.0 * x);
}
float ph_uv(float v, float res) { return v * (1.0 - 1.0 / res) + 0.5 / res; }

vec2 ph_intersect_sphere(float mu, float r, float R) {
   float disc = r * r * (mu * mu - 1.0) + R * R;
   if (disc < 0.0) return vec2(-1.0);
   disc = sqrt(disc);
   return -r * mu + vec2(-disc, disc);
}

float ph_nvidia_phase_area(float nu, float g, float a, float radius) {
   float re = max(radius, ph_eps);
   float mu = nu * cos(re) + sqrt(max(0.0, 1.0 - nu * nu)) * sin(re);
   if (nu > cos(re)) mu = 1.0;
   float gg = g * g;
   float p = 1.0 + gg - 2.0 * g * mu;
   return ((1.0 - gg) * (1.0 + a * mu * mu)) / (ph_pi * p * sqrt(p) * 4.0 * (1.0 + (a * (1.0 + 2.0 * gg)) / 3.0));
}

vec3 ph_mie_phase_sun(float nu) {
   return vec3(ph_nvidia_phase_area(nu, 0.85, 1.0, ph_sun_radius),
               ph_nvidia_phase_area(nu, 0.86, 1.0, ph_sun_radius),
               ph_nvidia_phase_area(nu, 0.87, 1.0, ph_sun_radius)) * 0.2;
}

vec3 ph_mie_phase_moon(float nu) {
   float t = float(moonPhase) / 4.0;
   t = t > 1.0 ? 2.0 - t : t;
   t = ph_sqr(1.0 - t) * 0.04 + 0.96;
   return vec3(ph_nvidia_phase_area(nu, 0.895 * t, 1.0, 2.0 * ph_moon_radius),
               ph_nvidia_phase_area(nu, 0.900 * t, 1.0, 2.0 * ph_moon_radius),
               ph_nvidia_phase_area(nu, 0.905 * t, 1.0, 2.0 * ph_moon_radius)) * 1.02;
}

vec3 ph_post(vec3 a) {
   return mix(vec3(dot(a, ph_lum2020)), a,
              (1.0 + atmosphere_saturation_boost_amount) * (1.0 - rainStrength));
}

#ifndef PH_LIGHT_ONLY
float ph_u_nu(float nu, float mu, float mu_s) {
   float h = sqrt(max(0.0, (1.0 - mu * mu) * (1.0 - mu_s * mu_s)));
   float lo = mu * mu_s - h, hi = mu * mu_s + h;
   float u = (lo == hi) ? lo : (nu - lo) / (hi - lo);
   return ph_uv(u, ph_scatter_res.x);
}

float ph_u_mu_s(float mu_s) {
   const float H = sqrt(ph_atmo_outer * ph_atmo_outer - ph_atmo_inner * ph_atmo_inner);
   float d_min = ph_atmo_thickness, d_max = H;
   float D = ph_intersect_sphere(ph_min_mu_s, ph_atmo_inner, ph_atmo_outer).y;
   float A = (D - d_min) / (d_max - d_min);
   float d = ph_intersect_sphere(mu_s, ph_atmo_inner, ph_atmo_outer).y;
   float a = (d - d_min) / (d_max - d_min);
   return ph_uv(max(0.0, 1.0 - a / A) / (1.0 + a), ph_scatter_res.z);
}

float ph_u_mu(float mu) {
   if (mu > 0.0) mu *= sqrt(sqrt(mu)); // stretch the horizon upwards
   const float r = ph_planet_radius;
   const float H = sqrt(ph_atmo_outer * ph_atmo_outer - ph_atmo_inner * ph_atmo_inner);
   const float rho = sqrt(max(0.0, r * r - ph_atmo_inner * ph_atmo_inner));
   float rmu = r * mu;
   float disc = rmu * rmu - r * r + ph_atmo_inner * ph_atmo_inner;
   if (mu < 0.0 && disc >= 0.0) {
      float d = -rmu - sqrt(max(0.0, disc));
      float d_min = r - ph_atmo_inner, d_max = rho;
      float u = d_max == d_min ? 0.0 : (d - d_min) / (d_max - d_min);
      return 0.5 - 0.5 * ph_uv(u, ph_scatter_res.y * 0.5);
   }
   float d = -rmu + sqrt(disc + H * H);
   float d_min = ph_atmo_outer - r, d_max = rho + H;
   return 0.5 + 0.5 * ph_uv((d - d_min) / (d_max - d_min), ph_scatter_res.y * 0.5);
}

// SCAVENGER: the moon's halo is much stronger near the horizon (long path through the air);
// scale it down, most of all while the moon is low.
float ph_moon_glow() {
   return PH_MOON_GLOW * mix(0.35, 1.0, smoothstep(0.0, 0.35, moon_dir.y));
}

// Sky radiance (Rec.2020, linear) for a world-space direction.
vec3 ph_atmosphere(vec3 ray, vec3 sunCol, vec3 moonCol, float sunGlow) {
   float mu = ray.y;
   float nu_s = dot(ray, sun_dir), nu_m = dot(ray, moon_dir);
   float mu_sun = sun_dir.y, mu_moon = moon_dir.y;

   float horizon_mu = mix(-0.01, 0.03, clamp(smoothstep(-0.05, 0.1, mu_sun) + smoothstep(0.05, 0.1, mu_moon), 0.0, 1.0));
   mu = max(mu, horizon_mu);

   float u_mu = ph_u_mu(mu);
   float uns = ph_u_nu(nu_s, mu, mu_sun), unm = ph_u_nu(nu_m, mu, mu_moon);
   float uss = ph_u_mu_s(mu_sun), usm = ph_u_mu_s(mu_moon);

   vec3 sc = texture(scavAtmosphereLUT, vec3(uns * 0.5,       u_mu, uss)).rgb;
   vec3 sm = texture(scavAtmosphereLUT, vec3(uns * 0.5 + 0.5, u_mu, uss)).rgb;
   vec3 mc = texture(scavAtmosphereLUT, vec3(unm * 0.5,       u_mu, usm)).rgb;
   vec3 mm = texture(scavAtmosphereLUT, vec3(unm * 0.5 + 0.5, u_mu, usm)).rgb;

   vec3 a = (sc + sm * ph_mie_phase_sun(nu_s) * sunGlow) * sunCol
          + (mc + mm * ph_mie_phase_moon(nu_m) * ph_moon_glow()) * moonCol;
   return ph_post(a);
}

#endif // PH_LIGHT_ONLY

float ph_chapman(float x, float c) {
   float k = sqrt(0.5 * ph_pi * x);
   if (c >= 0.0) return k / ((k - 1.0) * c + 1.0);
   float s = sqrt(clamp(1.0 - c * c, 0.0, 1.0));
   return k / ((k - 1.0) * c - 1.0) + 2.0 * k * exp(x - x * s) * sqrt(s);
}

vec3 ph_transmittance(float mu) {
   const float r = ph_planet_radius + 10.0;
   if (ph_intersect_sphere(mu, r, ph_planet_radius).x >= 0.0) return vec3(0.0);
   const vec3 ray = vec3(8.059375432e-06, 1.671209429e-05, 4.080133294e-05);
   const vec3 mie = vec3(1.666442358e-06, 1.812685127e-06, 1.958927896e-06);
   const vec3 ozo = vec3(8.304280072e-07, 1.314911970e-06, 5.440679729e-08);
   vec2 dens = exp(-10.0 / ph_scale_heights);
   vec2 airmass = ph_scale_heights * dens;
   airmass.x *= ph_chapman(r / ph_scale_heights.x, mu);
   airmass.y *= ph_chapman(r / ph_scale_heights.y, mu);
   vec3 ext = (ray * ph_rec709_to_rec2020) * airmass.x
            + (mie * ph_rec709_to_rec2020) * airmass.y
            + (ozo * ph_rec709_to_rec2020) * airmass.x;
   return clamp(exp(-ext), 0.0, 1.0);
}

// Photon's "magic" sun brightness and morning/evening tint (no auto exposure needed)
vec3 ph_sun_color() {
   float blue_hour = ph_linstep(0.05, 1.0, exp(-190.0 * ph_sqr(sun_dir.y + 0.09604)));
   float mul = 1.0 + 0.5 * (time_sunset + time_sunrise) + 40.0 * blue_hour;
   vec3 me = mix(vec3(1.0), vec3(1.05, 0.84, 0.93) * 1.2, ph_sqr(ph_pulse(sun_dir.y, 0.17, 0.40)));
   vec3 bh = mix(vec3(1.0), vec3(0.95, 0.80, 1.0), blue_hour);
   return 7.0 * PH_SUN_BRIGHTNESS * mul * me * bh;
}

vec3 ph_moon_color() {
   // Photon boosts the moon up to ~3.6x right after sunset; SCAVENGER keeps the midnight level all night
   const float boost = 1.33;
   vec3 tint = pow(vec3(PH_MOON_R, PH_MOON_G, PH_MOON_B), vec3(2.2)) * ph_rec709_to_rec2020;
   return 0.66 * PH_MOON_BRIGHTNESS * boost * tint;
}

vec3 ph_sun_disk(vec3 ray, vec3 sunCol) {
   float nu = clamp(dot(ray, sun_dir), -1.0, 1.0);
   float cte = max(0.0, ph_sun_radius - acos(nu));
   vec3 limb = pow(vec3(1.0 - ph_sqr(1.0 - cte)), 0.5 * vec3(0.429, 0.522, 0.614));
   float lum = 1.0 / (ph_tau * (1.0 - cos(ph_sun_radius)));
   return lum * sunCol * step(ph_eps, cte) * limb;
}

// cheap moon: lit disc using the phase, soft edge
vec4 ph_moon_disk(vec3 ray) {
   float MoV = dot(ray, moon_dir);
   float cr = cos(ph_moon_radius);
   if (MoV < cr) return vec4(0.0);
   float dist = clamp(acos(clamp(MoV, -1.0, 1.0)) / ph_moon_radius, 0.0, 1.0);

   vec3 t = normalize(cross(vec3(0.0, 1.0, 0.0001), moon_dir));
   vec3 b = cross(moon_dir, t);
   vec2 p = vec2(dot(ray - moon_dir, t), dot(ray - moon_dir, b)) / sin(ph_moon_radius);

   // phase terminator (0 = full, 4 = new)
   float ph = float(moonPhase);
   float k = cos(ph * 0.25 * ph_pi);
   float side = ph < 4.0 ? 1.0 : -1.0;
   float z = sqrt(max(0.0, 1.0 - dot(p, p)));
   float lit = smoothstep(-0.05, 0.05, side * p.x * 1.0 + k * z);

   vec3 col = vec3(PH_MOON_R, PH_MOON_G, PH_MOON_B) * (0.85 + 0.15 * z);
   float edge = 1.0 - smoothstep(0.9, 1.0, dist);
   return vec4(col * lit * 10.0 * PH_MOON_BRIGHTNESS * edge, edge);
}

float ph_hash(vec3 p) {
   p = fract(p * 0.3183099 + 0.1);
   p *= 17.0;
   return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

vec3 ph_stars(vec3 ray) {
   vec3 p = ray * 220.0;
   vec3 c = floor(p);
   float h = ph_hash(c);
   if (h < 0.985) return vec3(0.0);
   vec3 f = fract(p) - 0.5;
   float s = max(0.0, 1.0 - 4.0 * dot(f, f));
   float tw = ph_hash(c + 7.0);
   return vec3(mix(0.8, 1.0, tw), 0.9, mix(1.0, 0.85, tw)) * s * s * 0.06 * (h - 0.985) * 66.0;
}

#ifndef PH_LIGHT_ONLY
#ifdef SCAV_CLOUDS
   #include "/common/scavClouds.glsl"
#endif

// Full sky for a world-space view direction, Rec.2020 linear.
vec3 ph_sky(vec3 ray) {
   vec3 sunCol = ph_sun_color();
   vec3 moonCol = ph_moon_color();

   vec3 sky = vec3(0.0);
   float night = smoothstep(0.0, -0.15, sun_dir.y);
   sky += ph_stars(ray) * night * PH_STARS;
   sky += ph_sun_disk(ray, sunCol);
   vec4 moon = ph_moon_disk(ray);
   sky = sky * (1.0 - moon.a) + moon.rgb;

   sky *= ph_transmittance(ray.y) * (1.0 - rainStrength);
   vec3 atmo = ph_atmosphere(ray, sunCol, moonCol, PH_SUN_GLOW);
   sky += atmo;

   #ifdef SCAV_CLOUDS
      vec3 skyUp = ph_atmosphere(vec3(0.0, 1.0, 0.0), sunCol, moonCol, 0.0) * 1.6;
      float dth = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
      vec4 cl = scavClouds(ray, skyUp, atmo, dth);
      sky = sky * cl.a + cl.rgb;
   #endif

   // overcast: rain greys and dims the sky
   float l = dot(sky, ph_lum2020);
   sky = mix(sky, vec3(l) * 0.55, rainStrength * 0.6);
   return sky;
}

// Fog/air colour seen along a world-space direction (no sun disc, horizon-clamped).
vec3 ph_fog_color(vec3 ray) {
   ray.y = max(ray.y, 0.0);
   ray = normalize(ray + vec3(0.0, 0.02, 0.0));
   // fog gets only a little of the sun's halo, or everything toward the sun washes out white
   vec3 a = ph_atmosphere(ray, ph_sun_color(), ph_moon_color(), PH_SUN_GLOW * 0.25);
   float l = dot(a, ph_lum2020);
   return mix(a, vec3(l) * 0.55, rainStrength * 0.6);
}

#endif // PH_LIGHT_ONLY

// Timothy Lottes 2016 (Photon's default tonemap), then sRGB gamma.
vec3 ph_tonemap_lottes(vec3 rgb) {
   const vec3 a = vec3(1.5);
   const vec3 d = vec3(0.91);
   const vec3 hdr_max = vec3(8.0);
   const vec3 mid_in = vec3(0.26);
   const vec3 mid_out = vec3(0.32);
   vec3 b = (-pow(mid_in, a) + pow(hdr_max, a) * mid_out)
          / ((pow(hdr_max, a * d) - pow(mid_in, a * d)) * mid_out);
   vec3 c = (pow(hdr_max, a * d) * pow(mid_in, a) - pow(hdr_max, a) * pow(mid_in, a * d) * mid_out)
          / ((pow(hdr_max, a * d) - pow(mid_in, a * d)) * mid_out);
   return pow(rgb, a) / (pow(rgb, a * d) * b + c);
}

vec3 ph_to_display(vec3 rec2020) {
   vec3 c = max(rec2020 * ph_rec2020_to_rec709, 0.0) * PH_SKY_EXPOSURE;
   c = ph_tonemap_lottes(c);
   return pow(clamp(c, 0.0, 1.0), vec3(1.0 / 2.2));
}

// Hue of direct sunlight (Photon: sunlight * air transmittance * sun tint), unit length in Rec.709.
vec3 ph_light_hue() {
   vec3 c = ph_sunlight_color * ph_transmittance(max(sun_dir.y, 0.02)) * ph_sun_color();
   c = max(c * ph_rec2020_to_rec709, 0.0);
   return c / max(length(c), 1e-4);
}
