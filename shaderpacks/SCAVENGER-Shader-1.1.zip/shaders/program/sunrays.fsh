#include "/shader.h"

uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float viewWidth, viewHeight;
uniform int frameCounter;
uniform int isEyeInWater;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;

#ifdef DISTANT_HORIZONS
   uniform sampler2D dhDepthTex0;
   uniform mat4 dhProjectionInverse;
#endif

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.glsl"

float dither() {
   vec2 p = gl_FragCoord.xy + 5.588238 * mod(float(frameCounter), 64.0);
   return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

// is there no world (vanilla or LOD) at this screen position?
bool isSky(vec2 uv) {
   if (texture2D(depthtex0, uv).x < 1.0) return false;
   #ifdef DISTANT_HORIZONS
      if (texture2D(dhDepthTex0, uv).x < 1.0) return false;
   #endif
   return true;
}

vec3 lightTint() {
   float sunUp = (mat3(gbufferModelViewInverse) * normalize(sunPosition)).y;
   vec3 day = mix(vec3(1.0, 0.55, 0.25), vec3(1.0, 0.93, 0.82), clamp(sunUp * 4.0, 0.0, 1.0));
   return sunUp > -0.05 ? day * clamp(sunUp * 8.0 + 0.4, 0.0, 1.0) : MOON_COLOR * 0.8;
}

void main() {
   vec4 color = texture2D(colortex0, texUV);

   vec3 lightView = normalize(shadowLightPosition);
   if (lightView.z < 0.0) { // light in front of the camera
      vec4 clip = gbufferProjection * vec4(lightView * 100.0, 1.0);
      vec2 lightUV = clip2screen(clip).xy;

      vec2 delta = (lightUV - texUV) / float(SUN_RAYS_SAMPLES);
      vec2 uv = texUV + delta * dither();
      float acc = 0.0, w = 1.0, wsum = 0.0;

      for (int i = 0; i < SUN_RAYS_SAMPLES; i++) {
         if (uv.x > 0.0 && uv.x < 1.0 && uv.y > 0.0 && uv.y < 1.0) {
            acc += (isSky(uv) ? 1.0 : 0.0) * w;
         }
         wsum += w;
         w *= 0.94;
         uv += delta;
      }

      float rays = acc / wsum;

      // fade when the light is far off screen and toward the edge of the view
      vec2 aspect = vec2(viewWidth / viewHeight, 1.0);
      float onScreen = 1.0 - clamp(length((lightUV - 0.5) * aspect) - 0.6, 0.0, 1.0);
      float fromLight = 1.0 - clamp(length((texUV - lightUV) * aspect) * 0.9, 0.0, 1.0);

      float strength = SUN_RAYS_STRENGTH * (1.0 - 0.7 * rainStrength) * (isEyeInWater > 0 ? 0.0 : 1.0);
      vec3 add = lightTint() * rays * onScreen * fromLight * fromLight * strength;
      #ifdef SCAV_SKY
         // SCAVENGER 1.1: the Photon sky already glows around the sun; the rays should show
         // in the gaps between buildings/trees, not paint a white disc over open sky
         if (isSky(texUV)) add *= 0.2;
         color.rgb += add * (1.0 - color.rgb); // screen blend: brightens without clipping to white
      #else
         color.rgb += add;
      #endif
   }

   /* DRAWBUFFERS:0 */
   gl_FragData[0] = color;
}
