#include "/shader.h"

uniform sampler2D shadowtex1;
uniform vec3 fogColor;

uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
uniform vec3 sunPosition;
uniform float rainStrength;
uniform float viewWidth, viewHeight;
uniform int frameCounter;
uniform int isEyeInWater;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;

#ifdef DISTANT_HORIZONS
   uniform sampler2D dhDepthTex0;
   uniform mat4 dhProjectionInverse;
#endif

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.glsl"

float dither() {
   vec2 p = gl_FragCoord.xy + 5.588238 * mod(float(frameCounter), 64.0);
   return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

// is there no world (vanilla or LOD) at this screen position?
bool isSky(vec2 uv) {
   if (texture2D(depthtex0, uv).x < 1.0) return false;
   #ifdef DISTANT_HORIZONS
      if (texture2D(dhDepthTex0, uv).x < 1.0) return false;
   #endif
   return true;
}

vec3 lightTint() {
   float sunUp = (mat3(gbufferModelViewInverse) * normalize(sunPosition)).y;
   vec3 day = mix(vec3(1.0, 0.55, 0.25), vec3(1.0, 0.93, 0.82), clamp(sunUp * 4.0, 0.0, 1.0));
   return sunUp > -0.05 ? day * clamp(sunUp * 8.0 + 0.4, 0.0, 1.0) : MOON_COLOR * 0.8;
}

#include "/common/getShadowDistortion.glsl"
#include "/common/fogDegreen.glsl"
#ifdef SCAV_SKY
   #define PH_LIGHT_ONLY
   #include "/common/photonAtmosphere.glsl"
#endif

void main() {
   vec4 color = texture2D(colortex0, texUV);

   float depth = texture2D(depthtex0, texUV).x;
   vec3 viewPos = screen2view(texUV, depth);
   bool sky = depth >= 1.0;

   #ifdef DISTANT_HORIZONS
      if (sky) {
         float dhDepth = texture2D(dhDepthTex0, texUV).x;
         if (dhDepth < 1.0) {
            viewPos = nvec3(dhProjectionInverse * vec4(screen2ndc(vec3(texUV, dhDepth)), 1.0));
            sky = false;
         }
      }
   #endif

   vec3 origin = view2feet(vec3(0.0));
   vec3 feet   = view2feet(viewPos);
   vec3 dir    = normalize(feet - origin);
   float dist  = sky ? VL_DISTANCE : min(length(feet - origin), VL_DISTANCE);

   float stepLen = dist / float(VL_STEPS);
   float jitter  = dither();
   float lit = 0.0, haze = 0.0;

   for (int i = 0; i < VL_STEPS; i++) {
      vec3 p = origin + dir * (stepLen * (float(i) + jitter));

      // thicker near the ground, thinning out above VL_FOG_HEIGHT
      float y = p.y + cameraPosition.y;
      float dens = exp(-max(0.0, y - VL_FOG_HEIGHT) * 0.04);

      float visible = 1.0;
      #ifdef ENABLE_SHADOWS
         vec4 sc = shadowProjection * (shadowModelView * vec4(p, 1.0));
         sc.xyz = getShadowDistortion(sc.xyz);
         vec3 suv = clip2screen(sc);
         if (suv.x > 0.0 && suv.x < 1.0 && suv.y > 0.0 && suv.y < 1.0 && suv.z < 1.0) {
            visible = step(suv.z - 0.0005, texture2D(shadowtex1, suv.xy).x);
         }
      #endif

      lit  += visible * dens;
      haze += dens;
   }

   lit  /= float(VL_STEPS);
   haze /= float(VL_STEPS);

   // how much air the ray went through (thick enough to read as haze)
   float amount = 1.0 - exp(-dist * 0.025 * VL_FOG_DENSITY);
   if (sky) amount *= 0.5; // the sky already has its own glow

   // forward scattering: much brighter looking toward the sun/moon
   vec3 lightDir = mat3(gbufferModelViewInverse) * normalize(shadowLightPosition);
   float cosT = dot(dir, lightDir);
   float g = 0.78;
   float mie = (1.0 - g*g) / pow(1.0 + g*g - 2.0*g*cosT, 1.5) * 0.16;
   // SCAVENGER 1.1: the moon is a much weaker light; keep its halo small (big blue glow at moonrise otherwise)
   float sunUpVL = (mat3(gbufferModelViewInverse) * normalize(sunPosition)).y;
   if (sunUpVL <= -0.05) mie *= 0.2;
   float phase = 0.45 + mie;

   float weather = (1.0 - 0.2 * rainStrength) * (isEyeInWater > 0 ? 0.3 : 1.0);
   vec3 tint = lightTint();
   #ifdef SCAV_SKY
      // daytime haze takes Photon's sunlight colour (white, golden at sunrise/sunset) instead of yellow
      float sunUpT = (mat3(gbufferModelViewInverse) * normalize(sunPosition)).y;
      if (sunUpT > -0.05) tint = ph_light_hue() * 1.6 * clamp(sunUpT * 8.0 + 0.4, 0.0, 1.0);
   #endif

   // what the air looks like: sunlit haze where light reaches, dim fog-coloured haze in shadow
   float sunlit = lit / max(haze, 0.0001);
   vec3 litAir    = tint * phase * 1.4;
   #ifdef SCAV_SKY
      litAir = litAir / (1.0 + 0.6 * litAir); // soft roll-off so the haze toward the sun never clips to white
   #endif
   #ifdef SCAV_SKY
      // SCAVENGER 1.1: shaded air is cool blue-grey like Photon's, not olive
      vec3 shadowAir = mix(vec3(luma(fogColor)), vec3(0.50, 0.54, 0.60), 0.7) * 0.5;
   #else
      vec3 shadowAir = mix(vec3(luma(fogColor)), vec3(0.52, 0.55, 0.46), 0.7) * 0.5;
   #endif
   vec3 air = fogDegreen(mix(shadowAir, litAir, sunlit));

   float k = clamp(amount * haze * VL_STRENGTH * weather, 0.0, VL_MAX);
   color.rgb = mix(color.rgb, air, k);

   /* DRAWBUFFERS:0 */
   gl_FragData[0] = color;
}
