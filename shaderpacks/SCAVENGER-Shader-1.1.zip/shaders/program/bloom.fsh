#include "/shader.h"

const bool colortex0MipmapEnabled = true;

uniform sampler2D colortex0;
uniform float viewWidth, viewHeight;

varying vec2 texUV;

vec3 bright(vec2 uv, float lod) {
   vec3 c = textureLod(colortex0, uv, lod).rgb;
   float l = dot(c, vec3(0.299, 0.587, 0.114));
   return c * clamp((l - BLOOM_THRESHOLD) / (1.0 - BLOOM_THRESHOLD + 0.001), 0.0, 1.0);
}

vec3 blurLod(vec2 uv, float lod) {
   vec2 px = exp2(lod) / vec2(viewWidth, viewHeight);
   return 0.25 * (bright(uv + vec2( px.x,  px.y), lod) + bright(uv + vec2(-px.x,  px.y), lod)
                + bright(uv + vec2( px.x, -px.y), lod) + bright(uv + vec2(-px.x, -px.y), lod));
}

void main() {
   vec4 color = texture2D(colortex0, texUV);

   vec3 glow = blurLod(texUV, 2.0) * 0.30
             + blurLod(texUV, 3.0) * 0.30
             + blurLod(texUV, 4.0) * 0.25
             + blurLod(texUV, 5.0) * 0.15;

   color.rgb += glow * BLOOM_STRENGTH;

   /* DRAWBUFFERS:0 */
   gl_FragData[0] = color;
}
