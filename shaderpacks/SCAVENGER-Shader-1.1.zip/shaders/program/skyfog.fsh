#include "/shader.h"

// SCAVENGER: zone fog + render-distance fade, coloured by the Photon sky (composite, after translucents)

uniform float rainStrength;
uniform float far;
uniform int worldTime;
uniform int isEyeInWater;
uniform float blindness;
uniform float darknessFactor;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;

#ifdef DISTANT_HORIZONS
   uniform sampler2D dhDepthTex0;
   uniform mat4 dhProjectionInverse;
   uniform int dhRenderDistance;
#endif

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.glsl"
#include "/common/photonAtmosphere.glsl"
#include "/common/fogDegreen.glsl"
#include "/common/zoneFogAmount.glsl"

void main() {
   vec4 color = texture2D(colortex0, texUV);

   if (isEyeInWater == 0 && blindness <= 0.0 && darknessFactor <= 0.0) {
      float depth = texture2D(depthtex0, texUV).x;
      vec3 viewPos = screen2view(texUV, depth);
      bool sky = depth >= 1.0;
      float edge = far;

      #ifdef DISTANT_HORIZONS
         edge = max(float(dhRenderDistance), far);
         if (sky) {
            float dhDepth = texture2D(dhDepthTex0, texUV).x;
            if (dhDepth < 1.0) {
               viewPos = nvec3(dhProjectionInverse * vec4(screen2ndc(vec3(texUV, dhDepth)), 1.0));
               sky = false;
            }
         }
      #endif

      vec3 feet = view2eye(viewPos);
      float len = sky ? 1.0 : length(feet);
      vec3 ray = sky ? normalize(feet) : feet / max(len, 0.001);
      float mixAmt = 0.0;

      if (!sky) {
         // fade into the sky at the edge of the world (vanilla or LOD), smooth start
         float t = float(worldTime) * NORMALIZE_TIME;
         t = clamp(25.0 * (t < MIDNIGHT ? SUNSET - t : t - SUNRISE) + 0.3, OVERWORLD_FOG_MIN, OVERWORLD_FOG_MAX);
         t = min(t, 1.0 - rainStrength);
         float cyl = max(length(feet.xz), abs(feet.y));
         mixAmt = smoothstep(t * (edge - clamp(0.1 * edge, 4.0, 64.0)), edge, cyl);
      }

      #ifdef ZONE_FOG
         // SCAVENGER 1.1: height fog, integrated along the view ray. Thick in valleys and low ground,
         // thinning with altitude, and the SAME fog lies over the sky near the horizon, so distant
         // silhouettes melt into a haze band instead of ending in a hard edge.
         float zone = zoneFogAmount(ray, sky ? 3.0 * edge : len);
         mixAmt = max(mixAmt, zone);
      #endif

      if (mixAmt > 0.0) {
         vec3 fogCol = ph_to_display(ph_fog_color(ray));
         float l = luma(fogCol);
         fogCol = mix(vec3(l), fogCol, FOG_SKY_TINT);
         fogCol = fogDegreen(fogCol);
         color.rgb = mix(color.rgb, fogCol, clamp(mixAmt, 0.0, 1.0));
      }
   }

   /* DRAWBUFFERS:0 */
   gl_FragData[0] = color;
}
