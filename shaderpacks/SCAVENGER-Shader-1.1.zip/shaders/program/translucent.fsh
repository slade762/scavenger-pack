#include "/shader.h"

uniform float screenBrightness;
uniform ivec2 eyeBrightnessSmooth;
uniform sampler2D gtexture;

varying float fogMix;
varying float reflectivity;
varying float waterTexStrength;
varying vec2 lightUV;
varying vec2 texUV;
varying vec3 feetPos;
varying vec3 gradientFogColor;
varying vec3 normal;
varying vec4 ambient;
varying vec4 color;

#if HAND_DYNAMIC_LIGHTING == 0
   uniform int heldBlockLightValue;
#elif HAND_DYNAMIC_LIGHTING == 1
   #define heldBlockLightValue 14
#endif

#ifdef VOXY
   varying float vanillaMix;
#endif

#include "/common/math.glsl"
#include "/common/getTorchColor.fsh"

#ifdef DH_WATER
   uniform float far;
   uniform float viewWidth, viewHeight;
   uniform sampler2D depthtex1;
#endif

void main() {
   if (fogMix > 0.999) {
      discard;
   }

   #ifdef DH_WATER
      if (length(feetPos.xz) < far - 16.0) {
         discard;
      }

      // DH water is tested against DH's own depth only: hide it wherever a vanilla block
      // (always nearer than any LOD) is already drawn at this pixel
      if (texture2D(depthtex1, gl_FragCoord.xy / vec2(viewWidth, viewHeight)).x < 1.0) {
         discard;
      }

      vec4 albedo  = vec4(1.0, 1.0, 1.0, 0.8);
   #else
      vec4 albedo  = texture2D(gtexture, texUV);
   #endif
   vec4 ambient = ambient;
   vec4 color   = color;

   #ifdef VOXY
      vec4 vanilla = albedo * color * ambient;
   #endif

   if (reflectivity > WATER_REFLECTIVITY - 0.01) {
      #if MC_VERSION >= 11300
         albedo.rgb = rescale(albedo.rgb * waterTexStrength, vec3(WATER_GLINT_CUTOFF), vec3(1.0));
         albedo.rgb = vec3(WATER_BRIGHTNESS) + WATER_GLINT_BRIGHTNESS * albedo.rgb;

         #define WATER_BUFFER color
      #else
         #define WATER_BUFFER albedo
      #endif

      WATER_BUFFER.ba = min(WATER_BUFFER.ba, vec2(max(WATER_BUFFER.r, WATER_BUFFER.g)*WATER_B, WATER_A));
   }

   ambient.rgb += getTorchColor(lightUV.s, ambient.rgb, feetPos);

   albedo *= color * ambient;

   #ifdef VOXY
      float reflectivity = mix(reflectivity, 0.0, vanillaMix);

      albedo = mix(albedo, vanilla, vanillaMix);
   #endif

   albedo.rgb = mix(albedo.rgb, gradientFogColor, fogMix);

   /* DRAWBUFFERS:067 */
   gl_FragData[0] = albedo;
   gl_FragData[1] = vec4(normal, 1.0);
   #ifdef DH_WATER
      gl_FragData[2] = vec4(0.0, 0.0, 0.0, 1.0);
   #else
      gl_FragData[2] = vec4(reflectivity, 0.0, 0.5, 1.0);
   #endif
}