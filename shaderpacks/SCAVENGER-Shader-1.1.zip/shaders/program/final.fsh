#include "/shader.h"

uniform float far;
uniform int isEyeInWater;
uniform sampler2D colortex0;
uniform sampler2D colortex6;
uniform sampler2D colortex7;
uniform sampler2D depthtex0;

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.glsl"
#include "/common/getReflectionColor.fsh"

#ifdef PHOTON_TONE
// From Photon Shaders (SixthSurge, Photon Shaders License): HSL helpers + output grade
vec3 ph_rgb_to_hsl(vec3 c) {
   const vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
   vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));
   vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));
   float d = q.x - min(q.w, q.y);
   float e = 1e-6;
   return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
}
vec3 ph_hsl_to_rgb(vec3 c) {
   const vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
   c.yz = clamp(c.yz, 0.0, 1.0);
   vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
   return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);
}
float ph_isolate_hue(vec3 hsl, float center, float width) {
   if (hsl.y < 1e-2 || hsl.z < 1e-2) return 0.0;
   float x = (hsl.x * 360.0 - center + 180.0) / 360.0;
   x = abs(fract(x) * 360.0 - 180.0) / width;
   return x > 1.0 ? 0.0 : 1.0 - x * x * (3.0 - 2.0 * x);
}
vec3 ph_gain(vec3 x, float k) {
   vec3 a = 0.5 * pow(2.0 * mix(x, 1.0 - x, step(0.5, x)), vec3(k));
   return mix(a, 1.0 - a, step(0.5, x));
}
// Photon's grade_output, on our gamma-space colour: teal + orange saturation, gentle S-curve
vec3 photonTone(vec3 c) {
   vec3 rgb = sqrt(pow(clamp(c, 0.0, 1.0), vec3(2.2))); // ~perceptual, as in Photon
   vec3 hsl = ph_rgb_to_hsl(rgb);
   hsl.y *= 1.0 + PH_ORANGE_BOOST * ph_isolate_hue(hsl, 30.0, 20.0);
   hsl.y *= 1.0 + PH_TEAL_BOOST * ph_isolate_hue(hsl, 210.0, 20.0);
   rgb = ph_hsl_to_rgb(hsl);
   rgb = ph_gain(rgb, PH_GAIN);
   return pow(rgb * rgb, vec3(1.0 / 2.2));
}
#endif

void main() {
   vec4 color = texture2D(colortex0, texUV);
   vec4 reflectivityAndRoughness = texture2D(colortex7, texUV);
   float reflectivity = reflectivityAndRoughness.x;
   float roughness = reflectivityAndRoughness.y;

   if (reflectivity > MIN_REFLECTIVITY && abs(reflectivityAndRoughness.z - 0.5) < 0.01) {
      // the normal doesn't come premultiplied by the normal matrix to
      // avoid the modelview transformations when view bobbing is on
      // which causes severe artifacts when moving
      vec3 prenormal = screen2ndc(texture2D(colortex6, texUV).xyz);

      #if WATER_WAVE_SIZE > 0

         if ((abs(prenormal.x) > 0.0 || abs(prenormal.z) > 0.0) && abs(prenormal.y) > 0.3333) {
            prenormal.xyz *= 1.0 / prenormal.y;
            prenormal.xz *= 0.01 * WATER_WAVE_SIZE;
         }

      #endif

      float depth  = texture2D(depthtex0, texUV).x;
      vec3 normal  = eye2view(prenormal);
      vec3 viewPos = screen2view(texUV, depth);
      vec3 feetPos = view2feet(viewPos);
      vec3 worldPos = feet2world(feetPos);
      float pixelDistance = min(1.0, length(feetPos)/16.0);
      float stepSize = stepify(mix(1.0/512.0, 1.0/64.0, pixelDistance), 1.0/512.0);

      normal += roughness * random3(stepify(worldPos, stepSize));
      normal = normalize(normal);

      vec4 reflectionColor = getReflectionColor(depth, normal, viewPos);

      color.rgb = mix(
         color.rgb,
         reflectionColor.rgb,
         reflectionColor.a * reflectivity * 0.1*REFLECTIONS
      );
   }

   #ifdef PHOTON_TONE
      color.rgb = photonTone(color.rgb);
   #endif

   #ifdef COLOR_GRADE
      // SCAVENGER: washed-out, olive, slightly hard STALKER look
      float l = luma(color.rgb);
      color.rgb = mix(vec3(l), color.rgb, GRADE_SATURATION);
      color.rgb *= mix(vec3(1.0), vec3(0.96, 1.0, 0.84), GRADE_TINT);
      color.rgb = clamp((color.rgb - 0.5) * GRADE_CONTRAST + 0.5, 0.0, 1.0);

      vec2 v = texUV - 0.5;
      color.rgb *= 1.0 - GRADE_VIGNETTE * smoothstep(0.25, 0.75, dot(v, v) * 2.2);
   #endif

   #ifdef COLOR_GRADE
      // SCAVENGER: blend toward the "tarkov" preset from our Elaris grade (zta ElarisGrade.TARKOV)
      {
         const vec3 L = vec3(0.2126, 0.7152, 0.0722);
         vec3 c = clamp(color.rgb, 0.0, 1.0);
         vec3 g = mix(vec3(dot(c, L)), c, 0.76);
         g = g * vec3(0.940, 0.980, 1.030) + vec3(0.000, 0.006, 0.014) * (1.0 - g);
         g = pow(clamp(g, 0.0, 1.0), vec3(1.08));
         float l = dot(g, L);
         g += vec3(-0.016, 0.000, 0.020) * (1.0 - smoothstep(0.0, 0.5, l))
            + vec3(-0.010, 0.000, 0.012) * smoothstep(0.45, 1.0, l);
         g = clamp(g, 0.0, 1.0);
         g = mix(g, g * g * (3.0 - 2.0 * g), 0.22);
         color.rgb = mix(c, g, GRADE_TARKOV);
      }
   #endif

   gl_FragData[0] = color;
}