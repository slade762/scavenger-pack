#include "/shader.h"

// SCAVENGER depth of field (stage 3). Focus blur after Photon's c2_dof (SixthSurge, Photon Shaders
// License): circle of confusion from the screen-depth gap to the auto-focus point, Vogel disc samples.
// SCAVENGER additions: a distance blur that softens far terrain / low-detail Distant Horizons LODs,
// and mip-mapped samples so it stays smooth without TAA.

const bool colortex0MipmapEnabled = true;

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float far;
uniform float viewWidth, viewHeight;
uniform float aspectRatio;
uniform float centerDepthSmooth;
uniform int isEyeInWater;
uniform float rainStrength;
uniform float blindness;

#ifdef DISTANT_HORIZONS
   uniform sampler2D dhDepthTex0;
   uniform mat4 dhProjectionInverse;
   uniform int dhRenderDistance;
#endif

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.glsl"
#include "/common/zoneFogAmount.glsl"

vec2 vogel(int i, int n, float phi) {
   float r = sqrt((float(i) + 0.5) / float(n));
   float t = float(i) * 2.39996323 + phi;
   return r * vec2(cos(t), sin(t));
}

float focusDist; // distance (blocks) to what the crosshair is on

// view-space position and sky flag for a screen uv (vanilla depth, else DH LOD depth)
float cocAt(vec2 uv, float depth, out bool hand) {
   hand = depth < 0.56;
   vec3 viewPos = screen2view(uv, depth);
   bool sky = depth >= 1.0;

   #ifdef DISTANT_HORIZONS
      if (sky) {
         float dhDepth = texture2D(dhDepthTex0, uv).x;
         if (dhDepth < 1.0) {
            viewPos = nvec3(dhProjectionInverse * vec4(screen2ndc(vec3(uv, dhDepth)), 1.0));
            sky = false;
         }
      }
   #endif

   float coc = 0.0; // radius as a fraction of screen width

   #ifdef DOF_FOCUS_BLUR
      // Photon: blur by the screen-depth gap to what the crosshair is looking at
      coc = min(abs(depth - centerDepthSmooth), 0.1) * (DOF_INTENSITY * 0.2 / 1.37) * gbufferProjection[1][1];
   #endif

   // SCAVENGER: distance and fog blur follow your eyes too: things at or in front of what you
   // look at stay (mostly) sharp, things behind it go soft. A little always stays (FOCUS_KEEP),
   // so the far haze never turns back into a hard cut-out.
   float pixDist = sky ? 1e6 : length(viewPos);
   float behind = mix(DOF_FOCUS_KEEP, 1.0, smoothstep(focusDist * 1.1, focusDist * 1.6 + 24.0, pixDist));

   #ifdef DOF_DISTANCE_BLUR
      if (!sky) {
         float start = DOF_FAR_START * far;
         float t = smoothstep(start, start + DOF_FAR_RANGE * far, length(viewPos));
         coc = max(coc, t * DOF_FAR_STRENGTH * 0.012 * behind);
      }
   #endif

   #if defined ZONE_FOG && defined FOG_BLUR
      // SCAVENGER: fog scatters light, so foggy distance goes soft. The sky gets it too (its horizon
      // haze band), so far tree lines and rooftops blur INTO the haze instead of a hard cut-out edge.
      if (isEyeInWater == 0 && blindness <= 0.0) {
         vec3 feet = view2eye(viewPos);
         float edgeD = far;
         #ifdef DISTANT_HORIZONS
            edgeD = max(float(dhRenderDistance), far);
         #endif
         float fl = sky ? 1.0 : length(feet);
         float fog = zoneFogAmount(feet / max(length(feet), 0.001), sky ? 3.0 * edgeD : fl);
         coc = max(coc, fog * FOG_BLUR_STRENGTH * 0.010 * behind);
      }
   #endif

   if (isEyeInWater > 0) coc *= 0.5;
   return hand ? 0.0 : coc;
}

void main() {
   // what the crosshair is on: vanilla terrain (smoothed by Iris), else a DH LOD, else the sky
   focusDist = 1e6;
   if (centerDepthSmooth < 0.9999) {
      focusDist = length(screen2view(vec2(0.5), centerDepthSmooth));
   }
   #ifdef DISTANT_HORIZONS
      else {
         float dhc = texture2D(dhDepthTex0, vec2(0.5)).x;
         if (dhc < 1.0) focusDist = length(nvec3(dhProjectionInverse * vec4(screen2ndc(vec3(0.5, 0.5, dhc)), 1.0)));
      }
   #endif

   vec3 color = texture2D(colortex0, texUV).rgb;

   bool hand;
   float coc = cocAt(texUV, texture2D(depthtex0, texUV).x, hand);
   float radiusPx = coc * viewWidth;

   if (!hand && radiusPx > 0.75) {
      // low mip level only for smoothing between samples (higher levels look blocky)
      float lod = clamp(log2(radiusPx / sqrt(float(DOF_SAMPLES))) - 0.5, 0.0, 3.0);
      float phi = 6.2831853 * fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
      vec2 r = coc * vec2(1.0, aspectRatio);

      vec3 acc = color;
      float wsum = 1.0;
      for (int i = 0; i < DOF_SAMPLES; i++) {
         vec2 o = vogel(i, DOF_SAMPLES, phi);
         vec2 uv = clamp(texUV + o * r, vec2(0.001), vec2(0.999));
         bool h;
         float cs = cocAt(uv, texture2D(depthtex0, uv).x, h);
         // Only truly sharp samples (in-focus things, hands: blur radius under ~2 px) are kept out,
         // so they don't smear into a blurred background. Everything that is itself blurry blends
         // both ways; the old "does its blur reach this pixel" test let sky bleed into far buildings
         // but not buildings into the sky, which drew a bright rim like a sharpening halo.
         float w = smoothstep(0.5, 2.5, cs * viewWidth);
         acc += textureLod(colortex0, uv, lod).rgb * w;
         wsum += w;
      }
      color = acc / wsum;
   }

   /* DRAWBUFFERS:0 */
   gl_FragData[0] = vec4(color, 1.0);
}
