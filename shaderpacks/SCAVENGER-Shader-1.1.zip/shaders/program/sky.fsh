#include "/shader.h"

// SCAVENGER: replace the vanilla sky with Photon's precomputed atmosphere (deferred, before translucents/rain)

uniform float rainStrength;
uniform sampler2D colortex0;
uniform sampler2D depthtex0;

#ifdef DISTANT_HORIZONS
   uniform sampler2D dhDepthTex0;
#endif

varying vec2 texUV;

#include "/common/math.glsl"
#include "/common/transformations.glsl"
#include "/common/photonAtmosphere.glsl"

void main() {
   vec4 color = texture2D(colortex0, texUV);

   bool sky = texture2D(depthtex0, texUV).x >= 1.0;
   #ifdef DISTANT_HORIZONS
      if (texture2D(dhDepthTex0, texUV).x < 1.0) sky = false;
   #endif

   if (sky) {
      vec3 ray = normalize(view2eye(screen2view(texUV, 1.0)));
      color.rgb = ph_to_display(ph_sky(ray));
      // tiny dither against banding
      color.rgb += (fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5) / 255.0;
      color.a = 1.0;
   }

   /* DRAWBUFFERS:0 */
   gl_FragData[0] = color;
}
