#define SHADOW_DARKNESS 0.3 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define LIGHT_BRIGHTNESS 1.3 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5 1.55 1.6 1.65 1.7 1.75 1.8 1.85 1.9 1.95 2.0]

#define ENABLE_FOG
#define OVERWORLD_FOG_MAX_SLIDER 7 //[0 1 2 3 4 5 6 7 8 9 10]
#define OVERWORLD_FOG_MIN_SLIDER 0 //[0 1 2 3 4 5 6 7 8 9 10]
#define WEATHER_OPACITY 0.35 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

#define TORCH_INNER_R 1.0  //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_INNER_G 0.85 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_INNER_B 0.7  //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_MIDDLE_R 1.0 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_MIDDLE_G 0.8 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_MIDDLE_B 0.6 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_OUTER_R 1.0  //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_OUTER_G 0.55 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define TORCH_OUTER_B 0.2  //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define MOON_R 0.1  //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define MOON_G 0.15 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define MOON_B 0.3  //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]

#define BLOCK_REFLECTIONS 5  //[0 1 2 3 4 5 6 7 8 9 10]
#define REFLECTIONS 10       //[0 1 2 3 4 5 6 7 8 9 10]
#define SSR_MAX_STEPS 10     //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 24 32 64 96 128 256 512]
#define SSR_STEP_SIZE 1.6    //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
#define SSR_BINARY_STEPS 4   //[1 2 3 4 5 6 7 8 9 10]

#define SHADOW_PIXEL 16     //[0 4 8 16 32 64 128 256 512 1024 2048]
#define SHADOW_BLUENESS 0.3 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5]

const int   shadowMapResolution = 1024;  //[256 512 1024 2048 3072 4096]
const float shadowDistance      = 128.0; //[8.0 16.0 32.0 64.0 96.0 128.0 192.0 256.0 384.0 512.0 1024.0]
const float shadowIntervalSize  = 7.0;  //[1.0 2.0 3.0 4.0 5.0 6.0 7.0 8.0 9.0 10.0 11.0 12.0 13.0 14.0 15.0 16.0]
const float shadowDistanceRenderMul = 1.0;
const float entityShadowDistanceMul = 0.2; //[0.125 0.2 0.25 0.333 0.5 0.75 1.0]
const float sunPathRotation = 0.0; //[-90.0 -85.0 -80.0 -75.0 -70.0 -65.0 -60.0 -55.0 -50.0 -45.0 -40.0 -35.0 -30.0 -25.0 -20.0 -15.0 -10.0 -5.0 0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0 65.0 70.0 75.0 80.0 85.0 90.0]

#define WATER_WAVE_SIZE 1          //[0 1 2 3 4 5 6 7 8 9 10]
#define WATER_WAVE_SPEED 2         //[1 2 3 4 5 6 7 8 9 10]
#define WATER_BRIGHTNESS 0.4       //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define WATER_B 1.3                //[1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3.0]
#define WATER_A 0.7                //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define WATER_MIN_GLINT 6          //[-1 0 1 2 3 4 5 6 7 8 9 10]
#define WATER_GLINT_CUTOFF 0.6     //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define WATER_GLINT_BRIGHTNESS 0.8 //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.25 1.3 1.35 1.4 1.45 1.5 1.55 1.6 1.65 1.7 1.75 1.8 1.85 1.9 1.95 2.0]

#define END_STARS_SPEED  0.05  //[0.002 0.005 0.01 0.02 0.05 0.1 0.5]
#define END_STARS_AMOUNT 256.0 //[128.0 256.0 512.0 1024.0 2048.0]
#define END_STARS_FLOOR  256.0
#define END_STARS_OPACITY 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]

// SCAVENGER additions: volumetric light, sun rays, bloom (overworld)
#define VOLUMETRIC_LIGHT
#define VL_STRENGTH 0.5   //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.25 1.5 2.0]
#define VL_FOG_DENSITY 0.7 //[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.5 2.0]
#define VL_MAX 0.6 //[0.3 0.4 0.5 0.6 0.7 0.8 0.9]
#define VL_STEPS 8       //[6 8 10 12 16 20 24 32]
#define VL_DISTANCE 256.0  //[32.0 48.0 64.0 96.0 128.0 192.0 256.0]
#define VL_FOG_HEIGHT 64.0 //[40.0 50.0 60.0 64.0 70.0 80.0 90.0 100.0 120.0 150.0]
#define SUN_RAYS
#define SUN_RAYS_STRENGTH 1.0 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.25 1.5]
#define SUN_RAYS_SAMPLES 24   //[12 16 24 32 48]
#define BLOOM
// SCAVENGER sky (Photon port)
#define SCAV_SKY
#define PH_SKY_EXPOSURE 1.0 //[0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.4 1.6 1.8 2.0]
#define PH_SUN_BRIGHTNESS 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5]
#define PH_SUN_GLOW 0.35 //[0.0 0.1 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.8 1.0]
#define PH_SUN_SIZE 2.0 //[0.5 1.0 1.5 2.0 2.5 3.0 4.0]
#define PH_MOON_SIZE 3.0 //[1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0]
#define PH_MOON_BRIGHTNESS 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define PH_MOON_GLOW 0.3 //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.8 1.0]
#define PH_MOON_R 0.75 //[0.5 0.6 0.7 0.75 0.8 0.85 0.9 1.0]
#define PH_MOON_G 0.83 //[0.5 0.6 0.7 0.75 0.8 0.83 0.9 1.0]
#define PH_MOON_B 1.00 //[0.5 0.6 0.7 0.75 0.8 0.85 0.9 1.0]
#define PH_STARS 1.0 //[0.0 0.25 0.5 0.75 1.0 1.5 2.0]
#define FOG_SKY_TINT 1.0 //[0.0 0.25 0.5 0.75 1.0]
#define PH_LIGHT_TINT 100 //[0 25 50 75 100]
#define PHOTON_TONE
#define PH_TEAL_BOOST 0.15 //[0.0 0.05 0.10 0.15 0.20 0.30]
#define PH_ORANGE_BOOST 0.05 //[0.0 0.05 0.10 0.15 0.20 0.30]
#define PH_GAIN 1.05 //[1.0 1.02 1.05 1.08 1.10 1.15 1.20]
#define FOG_DEGREEN 1.0 //[0.0 0.25 0.5 0.75 1.0]
#define GRADE_TARKOV 0.25 //[0.0 0.1 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.75 1.0]
// backlit leaves
#define LEAF_SSS
#define LEAF_SSS_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0]
// clouds (stage 4)
#define SCAV_CLOUDS
#define CLOUD_COVERAGE 0.45 //[0.2 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.7 0.8]
#define CLOUD_ALTITUDE 520.0 //[256.0 320.0 400.0 520.0 640.0 800.0]
#define CLOUD_THICKNESS 380.0 //[150.0 200.0 280.0 380.0 500.0 650.0]
#define CLOUD_STEPS 16 //[8 12 16 20 24 32]
#define CLOUD_SPEED 4.0 //[0.0 1.0 2.0 4.0 8.0 16.0]
#define CLOUD_BRIGHTNESS 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.4]
// depth of field (stage 3)
#define DOF_FOCUS_BLUR
#define DOF_INTENSITY 0.5 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define DOF_DISTANCE_BLUR
#define DOF_FAR_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DOF_FAR_START 0.75 //[0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define DOF_FAR_RANGE 2.0 //[0.5 1.0 1.5 2.0 3.0 4.0 6.0]
#define FOG_BLUR
#define FOG_BLUR_STRENGTH 1.0 //[0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define DOF_FOCUS_KEEP 0.35 //[0.0 0.1 0.2 0.35 0.5 0.75 1.0]
#define DOF_SAMPLES 20 //[8 12 16 20 24 32]
#define ZONE_FOG
#define ZONE_FOG_DISTANCE 1500.0 //[60.0 80.0 100.0 120.0 150.0 180.0 220.0 260.0 320.0 400.0 500.0 650.0 800.0 1000.0 1500.0 2000.0 3000.0]
#define ZONE_FOG_MAX 0.5      //[0.5 0.6 0.7 0.75 0.8 0.85 0.9 0.95 1.0]
#define ZONE_FOG_START 400.0 //[0.0 50.0 100.0 150.0 200.0 300.0 400.0 500.0 700.0 1000.0]
#define ZONE_FOG_BASE 64.0 //[40.0 50.0 56.0 64.0 72.0 80.0 96.0 120.0]
#define ZONE_FOG_FALLOFF 100.0 //[20.0 30.0 40.0 60.0 80.0 100.0 140.0 200.0 300.0]
#define COLOR_GRADE
#define GRADE_SATURATION 1.0   //[0.3 0.4 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 1.0]
#define GRADE_TINT 0.2         //[0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define GRADE_CONTRAST 1.05     //[0.9 0.95 1.0 1.05 1.1 1.15 1.2 1.3]
#define GRADE_VIGNETTE 0.2    //[0.0 0.1 0.2 0.3 0.35 0.4 0.5 0.6 0.8]
#define BLOOM_STRENGTH 0.4  //[0.0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.5 0.6 0.8 1.0]
#define BLOOM_THRESHOLD 0.6  //[0.3 0.4 0.5 0.6 0.65 0.7 0.75 0.8 0.85 0.9]

#define FLAT_LIGHTING
#define GLOWING_ORES
#define HIGHLIGHT_WAXED
#define SHADOW_ENTITY 0 //[-1 0 1]
#define ENABLE_SKY
#define NETHER_COLOR_GRADING

#ifdef OVERWORLD
   #define ENABLE_SHADOWS
#endif

#if MC_VERSION >= 11300
   #define HAND_DYNAMIC_LIGHTING 0 //[-1 0 1]
#endif

// optifine needs these to show on menu
#ifdef ENABLE_FOG
#endif
#ifdef ENABLE_SKY
#endif
#ifdef FLAT_LIGHTING
#endif
#ifdef SHADOW_ENTITY
#endif
#ifdef NETHER_COLOR_GRADING
#endif
#ifdef VOLUMETRIC_LIGHT
#endif
#ifdef SUN_RAYS
#endif
#ifdef BLOOM
#endif
#ifdef ZONE_FOG
#endif
#ifdef COLOR_GRADE
#endif

//----------------------------------------------------------------------------//

#define MIN_REFLECTIVITY 0.01
#define WATER_REFLECTIVITY 0.99
#define GLASS_REFLECTIVITY 0.3

#define HALF_PI 1.570796326
#define PI 3.141592653
#define TAU 6.283185307
#define SQRT_2 1.414213562
#define NOON 0.25 // 6000
#define SUNSET 0.5325 // 12780
#define MIDNIGHT 0.75 // 18000
#define SUNRISE 0.9675 // 23220

const float INV_PI = 1.0 / PI;
const float INV_TAU = 1.0 / TAU;

const float NORMALIZE_TIME = 1.0/24000.0;

const float OVERWORLD_FOG_MIN = 1.0 - 0.1*OVERWORLD_FOG_MAX_SLIDER;
const float OVERWORLD_FOG_MAX = 1.0 - 0.1*OVERWORLD_FOG_MIN_SLIDER;

const vec2 AMBIENT_UV = vec2(8.0/255.0, 247.0/255.0);
const vec2 TORCH_UV_SCALE = vec2(8.0/255.0, 231.0/255.0);
const vec3 TORCH_INNER_COLOR = vec3(TORCH_INNER_R, TORCH_INNER_G, TORCH_INNER_B);
const vec3 TORCH_MIDDLE_COLOR = vec3(TORCH_MIDDLE_R, TORCH_MIDDLE_G, TORCH_MIDDLE_B);
const vec3 TORCH_OUTER_COLOR = vec3(TORCH_OUTER_R, TORCH_OUTER_G, TORCH_OUTER_B);
const vec3 MOON_COLOR = vec3(MOON_R, MOON_G, MOON_B);

const vec4 END_STARS_DRAG = vec4(200, 500, 100, 100);
const vec3 END_AMBIENT    = vec3(0.83, 0.7, 1.0);

const vec3 SHADOW_COLOR = vec3(1.0 - SHADOW_DARKNESS) + vec3(0.0, 0.3333, 1.0) * SHADOW_BLUENESS;

const float SHADOW_MAX_DIST_SQUARED = shadowDistance * shadowDistance;
const float INV_SHADOW_MAX_DIST_SQUARED = 1.0/SHADOW_MAX_DIST_SQUARED;