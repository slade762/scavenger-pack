#if !defined INCLUDE_LIGHTING_HEADLAMP_BEAMS
#define INCLUDE_LIGHTING_HEADLAMP_BEAMS

// SCAVENGER: visible headlamp beams in the air (volumetric), drawn in the layer-blend pass.
// Uses the same lamp data as the spotlights (zone_tactical_anims): your own lamp (ztaHeadlamp, from the eyes along
// playerLookVector) and up to 8 others (ztaLampP/D). For each lamp the view ray is marched only through the part that
// passes inside the lamp's range, so lamps far off screen cost almost nothing. Stops at the first surface behind
// (scene depth) and, for other people's lamps, at the wall their beam hits.
// zta draws no beam mesh while a shader pack is on; this replaces it.

uniform float ztaHeadlamp;
uniform vec3 playerLookVector;
uniform vec3 relativeEyePosition;
uniform int ztaLampCount;
uniform vec4 ztaLampP0, ztaLampP1, ztaLampP2, ztaLampP3, ztaLampP4, ztaLampP5, ztaLampP6, ztaLampP7;
uniform vec4 ztaLampD0, ztaLampD1, ztaLampD2, ztaLampD3, ztaLampD4, ztaLampD5, ztaLampD6, ztaLampD7;

// In-scattering of one lamp along the ray origin + t * dir, t in [0, max_t].
// lamp = lamp position (scene space), look = beam direction, reach = beam cut-off along its axis.
// near = how far in front of the camera this beam starts to count (0 = from the camera). Used for other people's
// lamps: when someone shines at you from behind, your camera sits inside their beam right by the lens; without
// this every pixel's ray starts in the hottest part and the per-frame jitter makes the whole screen flicker
// (Ward 11/25 19:33). Your own body would shadow that strip anyway.
float headlamp_beam_one(vec3 origin, vec3 dir, float max_t, vec3 lamp, vec3 look, float reach, float jitter, float hot, float near) {
    float range = min(HEADLAMP_RANGE, reach);

    // Ray vs. the lamp's range sphere: only march where it can matter
    vec3 oc = origin - lamp;
    float b = dot(oc, dir);
    float c = dot(oc, oc) - range * range;
    float h = b * b - c;
    if (h <= 0.0) return 0.0;
    h = sqrt(h);
    float t0 = max(-b - h, near * 0.3);
    float t1 = min(-b + h, max_t);
    if (t1 <= t0) return 0.0;

    float outer = cos(radians(HEADLAMP_ANGLE * HEADLAMP_BEAM_WIDTH));
    float inner = cos(radians(HEADLAMP_ANGLE * HEADLAMP_BEAM_WIDTH * 0.35));
    float ref = HEADLAMP_RANGE * 0.22;

    // Only march where the ray is actually inside the lit cone (Ward 11/25 20:17): standing inside someone's beam,
    // the ray leaves the cone part-way; with 10 jittered samples spread over the whole range sphere, how many of them
    // landed before the exit point changed every frame (+-40 %) = flicker. Clipping [t0, t1] to the cone first puts
    // every sample in the lit part, same average, steady. The forward nappe is convex, so the hit is one interval.
    {
        float da = dot(dir, look), oa = dot(oc, look), od = dot(oc, dir), oo = dot(oc, oc);
        float c2 = outer * outer;
        float qa = da * da - c2;
        float qb = 2.0 * (da * oa - c2 * od);
        float qc = oa * oa - c2 * oo;
        float r1 = t1, r2 = t1;
        if (abs(qa) < 1e-6) {
            if (abs(qb) > 1e-6) r1 = r2 = -qc / qb;
        } else {
            float disc = qb * qb - 4.0 * qa * qc;
            if (disc >= 0.0) {
                float sq = sqrt(disc);
                float ra = (-qb - sq) / (2.0 * qa), rb = (-qb + sq) / (2.0 * qa);
                r1 = min(ra, rb); r2 = max(ra, rb);
            }
        }
        // candidate break points inside (t0, t1): test the middle of each piece, keep the inside span
        float b1 = clamp(r1, t0, t1), b2 = clamp(r2, t0, t1);
        float lo = t1, hi = t0;
        float ms[3] = float[3](0.5 * (t0 + b1), 0.5 * (b1 + b2), 0.5 * (b2 + t1));
        float ls[3] = float[3](t0, b1, b2);
        float hs[3] = float[3](b1, b2, t1);
        for (int k = 0; k < 3; k++) {
            if (hs[k] - ls[k] < 1e-4) continue;
            vec3 q = oc + dir * ms[k];
            float qa2 = dot(q, look);
            if (qa2 > 0.0 && qa2 * qa2 >= c2 * dot(q, q)) { lo = min(lo, ls[k]); hi = max(hi, hs[k]); }
        }
        if (hi <= lo) return 0.0;
        // and stop where the beam is cut off along its axis (the wall it hits)
        if (abs(da) > 1e-6) {
            float tr = (reach - oa) / da;
            if (da > 0.0) hi = min(hi, tr); else lo = max(lo, tr);
        } else if (oa > reach) return 0.0;
        if (hi <= lo) return 0.0;
        t0 = lo; t1 = hi;
    }


    const int steps = HEADLAMP_BEAM_STEPS;
    float dt = (t1 - t0) / float(steps);
    float sum = 0.0;
    for (int i = 0; i < steps; i++) {
        float t = t0 + (float(i) + jitter) * dt;
        vec3 p = origin + dir * t - lamp;
        float d2 = dot(p, p);
        float d = sqrt(d2);
        if (d < 0.05) continue;
        float along = dot(p, look);
        if (along <= 0.0 || along > reach) continue;
        float cone = smoothstep(outer, inner, along / d);
        float falloff = 1.0 / (1.0 + d2 / (ref * ref));
        falloff *= 1.0 - smoothstep(range * 0.6, range, d);
        // a little brighter right at the lens (the hot spot people see first)
        float near_fade = near > 0.0 ? smoothstep(near * 0.3, near, t) : 1.0;
        sum += cone * falloff * near_fade * (1.0 + hot * exp(-d * 1.5));
    }
    return sum * dt;
}

// Returns light to add to the pixel. origin/dir: the view ray in scene space; max_t: distance to the first surface.
vec3 get_headlamp_beams(vec3 origin, vec3 dir, float max_t, float jitter) {
#if !defined HEADLAMP_BEAM || !defined HEADLAMP_BEAMS_VISIBLE
    return vec3(0.0);
#else
    max_t = min(max_t, HEADLAMP_RANGE * 2.0);
    float total = 0.0;

    if (ztaHeadlamp > 0.0) {
        vec3 lamp = vec3(0.0, 0.08, 0.0) - relativeEyePosition;
        total += headlamp_beam_one(origin, dir, max_t, lamp, normalize(playerLookVector), HEADLAMP_RANGE, jitter, 0.0, 0.0)
               * ztaHeadlamp * HEADLAMP_BEAM_SELF;
    }

#ifdef HEADLAMP_OTHERS
    float o = 0.0;
    if (ztaLampCount > 0 && ztaLampP0.w > 0.0) o += ztaLampP0.w * headlamp_beam_one(origin, dir, max_t, ztaLampP0.xyz, ztaLampD0.xyz, ztaLampD0.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    if (ztaLampCount > 1 && ztaLampP1.w > 0.0) o += ztaLampP1.w * headlamp_beam_one(origin, dir, max_t, ztaLampP1.xyz, ztaLampD1.xyz, ztaLampD1.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    if (ztaLampCount > 2 && ztaLampP2.w > 0.0) o += ztaLampP2.w * headlamp_beam_one(origin, dir, max_t, ztaLampP2.xyz, ztaLampD2.xyz, ztaLampD2.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    if (ztaLampCount > 3 && ztaLampP3.w > 0.0) o += ztaLampP3.w * headlamp_beam_one(origin, dir, max_t, ztaLampP3.xyz, ztaLampD3.xyz, ztaLampD3.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    if (ztaLampCount > 4 && ztaLampP4.w > 0.0) o += ztaLampP4.w * headlamp_beam_one(origin, dir, max_t, ztaLampP4.xyz, ztaLampD4.xyz, ztaLampD4.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    if (ztaLampCount > 5 && ztaLampP5.w > 0.0) o += ztaLampP5.w * headlamp_beam_one(origin, dir, max_t, ztaLampP5.xyz, ztaLampD5.xyz, ztaLampD5.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    if (ztaLampCount > 6 && ztaLampP6.w > 0.0) o += ztaLampP6.w * headlamp_beam_one(origin, dir, max_t, ztaLampP6.xyz, ztaLampD6.xyz, ztaLampD6.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    if (ztaLampCount > 7 && ztaLampP7.w > 0.0) o += ztaLampP7.w * headlamp_beam_one(origin, dir, max_t, ztaLampP7.xyz, ztaLampD7.xyz, ztaLampD7.w, jitter, 2.0, HEADLAMP_BEAM_NEAR);
    total += o;
#endif

    // Thicker air in rain: beams show up much more
    float density = HEADLAMP_BEAM_DENSITY * (1.0 + 2.0 * rainStrength);
    vec3 color = from_srgb(vec3(HEADLAMP_R, HEADLAMP_G, HEADLAMP_B));
    return color * (6.0 * HEADLAMP_INTENSITY * 0.01 * density * total);
#endif
}

#endif // INCLUDE_LIGHTING_HEADLAMP_BEAMS
