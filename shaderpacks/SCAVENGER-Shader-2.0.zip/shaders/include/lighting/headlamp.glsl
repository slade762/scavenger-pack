#if !defined INCLUDE_LIGHTING_HEADLAMP
#define INCLUDE_LIGHTING_HEADLAMP

// SCAVENGER headlamp spotlight.
// zone_tactical_anims feeds `ztaHeadlamp` (0 = off, >0 = brightness, fades on/off) while the local
// player's worn headlamp is on. The beam is a smooth per-pixel cone from the eyes along the look
// direction, in its own cool-white colour, independent of the vanilla lightmap (which Coloured
// Lights squashes) and of Sodium Dynamic Lights (which only lights in light-level steps).
// No ztaHeadlamp uniform (zta missing / old zta) = it stays 0 and nothing changes.

uniform float ztaHeadlamp;
uniform vec3 playerLookVector;
#if !(defined HANDHELD_LIGHTING && defined IS_IRIS)
uniform vec3 relativeEyePosition;
#endif

vec3 get_headlamp_lighting(vec3 scene_pos, vec3 normal, float ao) {
#ifndef HEADLAMP_BEAM
    return vec3(0.0);
#else
    if (ztaHeadlamp <= 0.0) return vec3(0.0);

    // Position relative to the lamp (the player's eyes, a touch above for the forehead)
    vec3 to_frag = scene_pos + relativeEyePosition - vec3(0.0, 0.08, 0.0);
    float dist_sq = dot(to_frag, to_frag);
    float dist = sqrt(dist_sq);
    if (dist > HEADLAMP_RANGE || dist < 1e-3) return vec3(0.0);
    vec3 dir = to_frag / dist;

    // Cone: bright core, soft edge, faint spill around it
    float cos_angle = dot(dir, normalize(playerLookVector));
    float outer = cos(radians(HEADLAMP_ANGLE));
    float inner = cos(radians(HEADLAMP_ANGLE * 0.45));
    float spill = cos(radians(min(HEADLAMP_ANGLE * 2.2, 89.0)));
    float cone = smoothstep(outer, inner, cos_angle);
    cone += HEADLAMP_SPILL * smoothstep(spill, outer, cos_angle) * (1.0 - cone);
    if (cone <= 0.0) return vec3(0.0);

    // Distance: inverse square with a soft near clamp, faded out at the range limit
    float ref = HEADLAMP_RANGE * 0.22;
    float falloff = 1.0 / (1.0 + dist_sq / (ref * ref));
    falloff *= 1.0 - smoothstep(HEADLAMP_RANGE * 0.65, HEADLAMP_RANGE, dist);

    // Facing: wrapped Lambert so the ground ahead (lit at a grazing angle) still reads
    float n_dot_l = dot(normal, -dir);
    float facing = clamp01(n_dot_l * 0.75 + 0.25) * step(-0.2, n_dot_l);

    vec3 color = from_srgb(vec3(HEADLAMP_R, HEADLAMP_G, HEADLAMP_B));

    return color * (blocklight_scale * HEADLAMP_INTENSITY * ztaHeadlamp)
         * cone * falloff * facing * mix(ao, 1.0, 0.5);
#endif
}

#endif // INCLUDE_LIGHTING_HEADLAMP
