#if !defined INCLUDE_LIGHTING_HEADLAMP
#define INCLUDE_LIGHTING_HEADLAMP

// SCAVENGER headlamp spotlight.
// zone_tactical_anims feeds `ztaHeadlamp` (0 = off, >0 = brightness, fades on/off) while the local
// player's worn headlamp is on. The beam is a smooth per-pixel cone from the eyes along the look
// direction, in its own cool-white colour, independent of the vanilla lightmap (which Coloured
// Lights squashes) and of Sodium Dynamic Lights (which only lights in light-level steps).
// No ztaHeadlamp uniform (zta missing / old zta) = it stays 0 and nothing changes.

uniform float ztaHeadlamp;
uniform vec3 playerLookVector;

// zta 0.92.0: other people's lit headlamps (players + NPCs), nearest 8.
//   ztaLampP{i}.xyz = lamp position relative to the camera (scene space), .w = brightness 0..1 (0 = slot unused)
//   ztaLampD{i}.xyz = beam direction, .w = how far the beam gets before it hits a wall (blocks)
uniform int ztaLampCount;
uniform vec4 ztaLampP0, ztaLampP1, ztaLampP2, ztaLampP3, ztaLampP4, ztaLampP5, ztaLampP6, ztaLampP7;
uniform vec4 ztaLampD0, ztaLampD1, ztaLampD2, ztaLampD3, ztaLampD4, ztaLampD5, ztaLampD6, ztaLampD7;
#if !(defined HANDHELD_LIGHTING && defined IS_IRIS)
uniform vec3 relativeEyePosition;
#endif

// One spotlight: cone + distance falloff + facing. `to_frag` = fragment minus lamp position.
float headlamp_spot(vec3 to_frag, vec3 look, vec3 normal, out vec3 dir) {
    float dist_sq = dot(to_frag, to_frag);
    float dist = sqrt(dist_sq);
    dir = vec3(0.0, 1.0, 0.0);
    if (dist > HEADLAMP_RANGE || dist < 1e-3) return 0.0;
    dir = to_frag / dist;

    float cos_angle = dot(dir, look);
    float outer = cos(radians(HEADLAMP_ANGLE));
    float inner = cos(radians(HEADLAMP_ANGLE * 0.45));
    float spill = cos(radians(min(HEADLAMP_ANGLE * 2.2, 89.0)));
    float cone = smoothstep(outer, inner, cos_angle);
    cone += HEADLAMP_SPILL * smoothstep(spill, outer, cos_angle) * (1.0 - cone);
    if (cone <= 0.0) return 0.0;

    float ref = HEADLAMP_RANGE * 0.22;
    float falloff = 1.0 / (1.0 + dist_sq / (ref * ref));
    falloff *= 1.0 - smoothstep(HEADLAMP_RANGE * 0.65, HEADLAMP_RANGE, dist);

    float n_dot_l = dot(normal, -dir);
    float facing = clamp01(n_dot_l * 0.75 + 0.25) * step(-0.2, n_dot_l);
    return cone * falloff * facing;
}

#ifdef HEADLAMP_OTHERS
// Someone else's lamp: same beam, cut off just past the first wall it hits (zta raycasts it), so it doesn't shine
// through walls into the next room.
float headlamp_other(vec4 p, vec4 d, vec3 scene_pos, vec3 normal) {
    if (p.w <= 0.0) return 0.0;
    vec3 to_frag = scene_pos - p.xyz;
    float along = dot(to_frag, d.xyz);
    if (along > d.w) return 0.0;
    vec3 dir;
    float s = headlamp_spot(to_frag, d.xyz, normal, dir);
    return s * p.w * (1.0 - smoothstep(d.w - 1.5, d.w, along));
}
#endif

vec3 get_headlamp_lighting(vec3 scene_pos, vec3 normal, float ao) {
#ifndef HEADLAMP_BEAM
    return vec3(0.0);
#else
    vec3 color = from_srgb(vec3(HEADLAMP_R, HEADLAMP_G, HEADLAMP_B));
    float total = 0.0;

#ifdef HEADLAMP_OTHERS
    if (ztaLampCount > 0) {
        float o = headlamp_other(ztaLampP0, ztaLampD0, scene_pos, normal);
        if (ztaLampCount > 1) o += headlamp_other(ztaLampP1, ztaLampD1, scene_pos, normal);
        if (ztaLampCount > 2) o += headlamp_other(ztaLampP2, ztaLampD2, scene_pos, normal);
        if (ztaLampCount > 3) o += headlamp_other(ztaLampP3, ztaLampD3, scene_pos, normal);
        if (ztaLampCount > 4) o += headlamp_other(ztaLampP4, ztaLampD4, scene_pos, normal);
        if (ztaLampCount > 5) o += headlamp_other(ztaLampP5, ztaLampD5, scene_pos, normal);
        if (ztaLampCount > 6) o += headlamp_other(ztaLampP6, ztaLampD6, scene_pos, normal);
        if (ztaLampCount > 7) o += headlamp_other(ztaLampP7, ztaLampD7, scene_pos, normal);
        total += o * HEADLAMP_OTHERS_INTENSITY;
    }
#endif

    if (ztaHeadlamp <= 0.0) {
        return color * (blocklight_scale * total) * mix(ao, 1.0, 0.5);
    }

    // Your own lamp: from the eyes (a touch above, the forehead) along where you look
    vec3 to_frag = scene_pos + relativeEyePosition - vec3(0.0, 0.08, 0.0);
    vec3 dir;
    total += headlamp_spot(to_frag, normalize(playerLookVector), normal, dir) * HEADLAMP_INTENSITY * ztaHeadlamp;

    return color * (blocklight_scale * total) * mix(ao, 1.0, 0.5);
#endif
}

#endif // INCLUDE_LIGHTING_HEADLAMP
